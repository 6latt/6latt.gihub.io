(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [534],
  {
    7873: function (e, A, s) {
      "use strict";
      s.d(A, {
        Z: function () {
          return j;
        },
      });
      var c = s(5893),
        t = s(1922),
        n = {
          src: "/_next/static/media/i1.f8c12cde.jpg",
          height: 1280,
          width: 1280,
          blurDataURL:
            "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAdEAACAQQDAAAAAAAAAAAAAAABAgADBAURIUFx/8QAFAEBAAAAAAAAAAAAAAAAAAAAAf/EABcRAQADAAAAAAAAAAAAAAAAAAEAAhH/2gAMAwEAAhEDEQA/AKXHZZ7pESiilhUbQck6XXPncREKukbGM//Z",
          blurWidth: 8,
          blurHeight: 8,
        },
        r = {
          src: "/_next/static/media/i2.f6501871.jpg",
          height: 1280,
          width: 1280,
          blurDataURL:
            "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAeEAACAQMFAAAAAAAAAAAAAAAAAwECBBIFEyExYv/EABQBAQAAAAAAAAAAAAAAAAAAAAL/xAAVEQEBAAAAAAAAAAAAAAAAAAAAEf/aAAwDAQACEQMRAD8Aua8+by421qnJGVM+uOwACE//2Q==",
          blurWidth: 8,
          blurHeight: 8,
        },
        i = {
          src: "/_next/static/media/i3.f2352494.jpg",
          height: 1280,
          width: 1280,
          blurDataURL:
            "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAbEAACAwEBAQAAAAAAAAAAAAABAgADEQQFIv/EABUBAQEAAAAAAAAAAAAAAAAAAAID/8QAFxEBAQEBAAAAAAAAAAAAAAAAAQACEf/aAAwDAQACEQMRAD8ArPO9Ozo7rFfk+6WCVEMQrIc06RmxEQZe1NAX/9k=",
          blurWidth: 8,
          blurHeight: 8,
        },
        a = {
          src: "/_next/static/media/i4.29dece01.jpg",
          height: 1280,
          width: 1280,
          blurDataURL:
            "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAeEAABBAEFAAAAAAAAAAAAAAABAAIDIQQFERMxUf/EABQBAQAAAAAAAAAAAAAAAAAAAAP/xAAWEQEBAQAAAAAAAAAAAAAAAAABAAL/2gAMAwEAAhEDEQA/AKlmv8+IRBjSxueQN5G0L6r1ERE6ZDA3/9k=",
          blurWidth: 8,
          blurHeight: 8,
        },
        l = {
          src: "/_next/static/media/i5.5ab7565c.jpg",
          height: 1280,
          width: 1280,
          blurDataURL:
            "data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAIAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAb/xAAcEAABBAMBAAAAAAAAAAAAAAACAAEDBBESIUH/xAAVAQEBAAAAAAAAAAAAAAAAAAACA//EABYRAQEBAAAAAAAAAAAAAAAAAAEAEf/aAAwDAQACEQMRAD8AqTsynUepJAc0JtzUdcNhvfeoiKaswMv/2Q==",
          blurWidth: 8,
          blurHeight: 8,
        },
        d = s(830),
        o = s.n(d),
        h = s(2475),
        x = s.n(h);
      let u = () =>
        (0, c.jsxs)(c.Fragment, {
          children: [
            (0, c.jsx)("div", {
              className: "quote",
              children: (0, c.jsx)("q", {
                children:
                  "We always say no to gambling, child involvement, or discrimination of any kind.",
              }),
            }),
            (0, c.jsxs)("div", {
              className: o().row2222,
              children: [
                (0, c.jsx)("div", {}),
                (0, c.jsx)("div", {
                  className: "text",
                  children: (0, c.jsxs)("div", {
                    children: [
                      (0, c.jsx)("h2", {
                        className: "h2indent",
                        children: "We are loyal",
                      }),
                      (0, c.jsx)("p", {
                        children:
                          "When you become one of us, you will get 100% support and loyalty at all times. In conflict, sickness, or downside of life, we will have your back and make sure nothing pushes you over the edge.",
                      }),
                      (0, c.jsx)("h2", {
                        className: "h2indent",
                        children: "We say no",
                      }),
                      (0, c.jsx)("p", {
                        children:
                          "If a client relationship isn’t working, we say no. If a client treats their colleagues badly, we say no. We always say no to gambling, child involvement, or discrimination of any kind. Mutual respect is the foundation for our business and how we choose our clients.",
                      }),
                    ],
                  }),
                }),
                (0, c.jsx)("div", {
                  className: "text",
                  children: (0, c.jsxs)("div", {
                    children: [
                      (0, c.jsx)("h2", {
                        className: "h2indent",
                        children: "We are independent",
                      }),
                      (0, c.jsx)("p", {
                        children:
                          "We are a privately owned bootstrapped company that was built using hard work and talent, without external investments. No-one gets to tell us what to do or how we should run our business.",
                      }),
                      (0, c.jsx)("h2", {
                        className: "h2indent",
                        children: "We grow slow",
                      }),
                      (0, c.jsx)("p", {
                        children:
                          "We want to be the best – not the biggest. Having new people at the coffee machine every week is not our thing. It might seem ironic doing what we do for our clients, but we don’t see fast-growing as a self-fulfilling prophecy for our own success.",
                      }),
                    ],
                  }),
                }),
              ],
            }),
            (0, c.jsx)("div", { className: o().space2 }),
            (0, c.jsxs)("div", {
              className: o().row2222,
              children: [
                (0, c.jsx)("div", { children: (0, c.jsx)(t.Z, { src: a }) }),
                (0, c.jsx)("div", { children: (0, c.jsx)(t.Z, { src: r }) }),
                (0, c.jsx)("div", {}),
                (0, c.jsx)("div", { children: (0, c.jsx)(t.Z, { src: i }) }),
              ],
            }),
            (0, c.jsxs)("div", {
              className: o().row2222,
              children: [
                (0, c.jsx)("div", { children: (0, c.jsx)(t.Z, { src: n }) }),
                (0, c.jsx)("div", {}),
                (0, c.jsx)("div", { children: (0, c.jsx)(t.Z, { src: l }) }),
                (0, c.jsx)("div", {
                  className: "text",
                  children: (0, c.jsx)("p", {
                    children:
                      "Our beautiful, spacious office in a 19th-century building has a bar, gym, relax room, and serves breakfast every week!",
                  }),
                }),
              ],
            }),
            (0, c.jsx)("div", { className: o().space2 }),
            (0, c.jsxs)("div", {
              className: o().row134,
              children: [
                (0, c.jsx)("div", {}),
                (0, c.jsx)("div", {
                  className: x().benefits,
                  "data-rainbow": !0,
                  children: (0, c.jsxs)("dl", {
                    className: "facts",
                    children: [
                      (0, c.jsx)("dt", { children: "Benefits" }),
                      (0, c.jsx)("dd", { children: "Hybrid remote" }),
                      (0, c.jsx)("dd", { children: "6 weeks paid vacation" }),
                      (0, c.jsx)("dd", { children: "Laptop" }),
                      (0, c.jsx)("dd", { children: "Paid phone" }),
                      (0, c.jsx)("dd", {
                        children: "Noise cancelling headphones",
                      }),
                      (0, c.jsx)("dd", { children: "Great health insurance" }),
                      (0, c.jsx)("dd", { children: "Pension package" }),
                      (0, c.jsx)("dd", {
                        children: "Maxed health care allowance",
                      }),
                      (0, c.jsx)("dd", {
                        children: "Flexible work/life balance",
                      }),
                    ],
                  }),
                }),
                (0, c.jsxs)("div", {
                  className: "text",
                  children: [
                    (0, c.jsx)("p", {
                      children:
                        "Aino is an equal opportunity employer that is committed to inclusion in the workplace. We prohibit discrimination and harassment of any kind based on race, color, sex, religion, sexual orientation, national origin, disability, or any other protected characteristic.",
                    }),
                    (0, c.jsxs)("p", {
                      children: [
                        "For further questions:",
                        " ",
                        (0, c.jsx)("a", {
                          href: "mailto:linnea@aino.agency",
                          children: "linnea@aino.agency",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
      var j = u;
    },
    1922: function (e, A, s) {
      "use strict";
      var c = s(5893),
        t = s(5675),
        n = s.n(t),
        r = s(7294),
        i = s(274),
        a = s.n(i),
        l = s(313),
        d = s(2674),
        o = s(6760);
      let h = (e) => new Promise((A) => setTimeout(A, e)),
        x = [],
        u = (e) => {
          let {
              src: A,
              immediate: s = !1,
              sizes: t,
              alwaysText: i = !1,
              onLoadingComplete: u,
            } = e,
            [j, p] = (0, r.useState)(x.includes(A.src)),
            g = (0, r.useRef)(null),
            z = (0, r.useRef)(null),
            w = (0, r.useRef)(null),
            m = (0, r.useRef)(null),
            E = (0, r.useRef)(null),
            v = (0, r.useRef)(null),
            f = (0, r.useRef)((e) => e / 12),
            C = (0, r.useRef)(null),
            O = (0, r.useRef)(null),
            M = (0, r.useRef)(null),
            [b, B] = (0, r.useState)({}),
            D = (0, r.useRef)(!1),
            Q = (0, r.useRef)(s),
            _ = (e) => {
              g.current && (g.current.innerHTML = e);
            },
            { textMode: I, rainbowMode: y } = (0, d.Z)(),
            N = (0, r.useCallback)(() => {
              if (
                w.current &&
                z.current &&
                C.current &&
                O.current &&
                M.current &&
                m.current
              ) {
                let { width: e, height: A } = z.current.getBoundingClientRect();
                if (!e || !A) {
                  console.warn("Width or height is zero in the image wrapper");
                  return;
                }
                let s =
                  I || i
                    ? Math.ceil(A / window._lineHeight) * window._lineHeight
                    : A;
                (z.current.style.paddingBottom = "".concat((s / e) * 100, "%")),
                  (w.current.style.width = "".concat(e, "px")),
                  (w.current.style.height = "".concat(s, "px")),
                  (C.current.width = f.current(e)),
                  (C.current.height = f.current(s)),
                  (w.current.width = e),
                  (w.current.height = s),
                  O.current.drawImage(
                    v.current,
                    0,
                    0,
                    f.current(e),
                    f.current(s)
                  ),
                  I || i
                    ? (M.current.ctx.drawImage(C.current, 0, 0, e, s),
                      _(M.current.getChars()))
                    : ((m.current.imageSmoothingEnabled = !1),
                      (m.current.webkitImageSmoothingEnabled = !1),
                      m.current.drawImage(C.current, 0, 0, e, s));
              }
            }, [v, I]);
          (0, r.useEffect)(() => {
            w.current &&
              ((m.current = w.current.getContext("2d")),
              (m.current.webkitImageSmoothingEnabled = !1),
              (m.current.imageSmoothingEnabled = !1));
          }, []),
            (0, r.useEffect)(() => {
              if (
                E.current &&
                z.current &&
                ((!M.current && !C.current) || I || i)
              ) {
                var e, A;
                (M.current = (0, l.ZP)(g.current)),
                  (C.current = document.createElement("canvas")),
                  (O.current = C.current.getContext("2d")),
                  (v.current = E.current),
                  m.current && (m.current.imageSmoothingEnabled = !1),
                  window.addEventListener("resize", N),
                  (
                    null === (e = E.current) || void 0 === e
                      ? void 0
                      : e.complete
                  )
                    ? N()
                    : null === (A = E.current) ||
                      void 0 === A ||
                      A.addEventListener("load", N);
              }
              return () => {
                window.removeEventListener("resize", N);
              };
            }, [N, I]);
          let L = async () => {
              if (z.current) {
                let e = z.current.querySelector("img");
                if (e) {
                  if (((v.current = e), I || x.includes(A.src))) I && N();
                  else
                    for (let s = 16; s > 0; s -= 3)
                      await h(40), (f.current = (e) => e / s), N();
                  p(!0), x.push(A.src);
                }
              }
              u && u();
            },
            k = "/_next/image?url=".concat(
              encodeURIComponent(A.src),
              "&w=64&q=20"
            ),
            R = {};
          return (
            t && (R.sizes = t),
            (0, r.useEffect)(() => {
              B(I && y ? { "data-rainbow": !0 } : {});
            }, [y, I]),
            (0, c.jsxs)("div", {
              className: [
                a().wrapper,
                j ? a().loaded : "",
                I || i ? a().textMode : "",
              ].join(" "),
              ref: z,
              style: {
                paddingBottom: "".concat((A.height / A.width) * 100, "%"),
              },
              ...b,
              children: [
                (0, c.jsx)(o.h, {
                  onEnter() {
                    (Q.current = !0), D.current && L();
                  },
                }),
                (0, c.jsx)(n(), {
                  src: A,
                  alt: "",
                  onLoadingComplete() {
                    (D.current = !0), Q.current && L();
                  },
                  ...R,
                }),
                (0, c.jsxs)("div", {
                  className: a().loader,
                  children: [
                    (0, c.jsx)("img", { src: k, ref: E, alt: "", width: "64" }),
                    (0, c.jsx)("canvas", { ref: w }),
                  ],
                }),
                (0, c.jsx)("div", { className: a().letters, ref: g }),
              ],
            })
          );
        };
      A.Z = u;
    },
    3848: function (e, A, s) {
      "use strict";
      s.d(A, {
        Z: function () {
          return m;
        },
      });
      var c = s(5893),
        t = s(9515),
        n = s(5434),
        r = s(3067),
        i = s(830),
        a = s.n(i),
        l = s(1664),
        d = s.n(l),
        o = s(7294),
        h = s(9402),
        x = s(4276),
        u = s(2936),
        j = s.n(u);
      let p = [
          "open po5ition",
          "op3n position",
          "open p*sition",
          "open pos1tion",
        ],
        g = [{ x: 2, y: 0 }],
        z = (e) => {
          let {
              title: A,
              type: s = "Full-time",
              place: t = "Goth3nburg, Sweden",
              url: n,
              icon: r,
              headline: i,
              index: a,
            } = e,
            l = (0, o.useRef)(null),
            u = (0, o.useCallback)((e) => {
              l.current && (l.current.innerHTML = e);
            }, []);
          return (
            (0, o.useEffect)(() => {
              let e = !0,
                c =
                  innerWidth > 767
                    ? (window._cols - 3) / 4 - 2
                    : window._cols - 4,
                n = Math.floor(c / 2.1),
                r = [
                  i || p[Math.floor(Math.random() * p.length)],
                  "",
                  A,
                  "",
                  s,
                  t,
                ],
                {
                  createPoint: a,
                  update: d,
                  getText: o,
                  setGravity: j,
                } = (0, x.Z)({
                  width: c,
                  height: n,
                  gravity: g[Math.floor(Math.random() * g.length)],
                }),
                z = [];
              for (let w = 0; w < r.length; w++) {
                let m = r[w].split("");
                for (let E = 0; E < m.length; E++)
                  z.push(a({ x: E / c, y: w / n, value: m[E], mass: 100 }));
              }
              let v = Date.now(),
                f = () => {
                  let A = Date.now();
                  d(A - v), u(o()), (v = A), e || requestAnimationFrame(f);
                };
              if ((f(), l.current)) {
                let C;
                l.current.addEventListener("mouseenter", () => {
                  "ontouchstart" in window ||
                    ((v = Date.now()), (e = !1), C && C.stop(), f());
                }),
                  l.current.addEventListener("mouseleave", () => {
                    (e = !0),
                      setTimeout(() => {
                        v = Date.now();
                        let e = z.map((e) => ({ x: e.pos.x, y: e.pos.y }));
                        C = (0, h.Z)({
                          duration: 800,
                          onFrame(A) {
                            for (let s = 0; s < z.length; s++) {
                              let c = z[s].originalPos.x - e[s].x,
                                t = z[s].originalPos.y - e[s].y;
                              (z[s].pos.x = e[s].x + c * A),
                                (z[s].pos.y = e[s].y + t * A),
                                (z[s].vel.x = 0),
                                (z[s].vel.y = 0);
                            }
                            let n = Date.now();
                            d(n - v), u(o()), (v = n);
                          },
                        });
                      }, 50);
                  });
              }
            }, [u, t, A, s]),
            (0, c.jsx)("div", {
              className: j().job,
              "data-index": a,
              children: (0, c.jsx)(d(), {
                href: n,
                children: (0, c.jsxs)("div", {
                  "data-rainbow": !0,
                  className: j().innerlink,
                  children: [
                    (0, c.jsx)("div", {
                      ref: l,
                      className: j().text,
                      children: (0, c.jsxs)("div", {
                        className: j().ssr,
                        children: [
                          (0, c.jsx)("h2", { children: i || "Open position" }),
                          (0, c.jsxs)("ul", {
                            children: [
                              (0, c.jsx)("li", { children: A }),
                              (0, c.jsx)("li", { children: s }),
                              (0, c.jsx)("li", { children: t }),
                            ],
                          }),
                        ],
                      }),
                    }),
                    (0, c.jsx)("div", { className: j().icon, children: r }),
                    (0, c.jsx)("div", {
                      className: j().apply,
                      children: "Apply →",
                    }),
                  ],
                }),
              }),
            })
          );
        },
        w = () =>
          (0, c.jsxs)(c.Fragment, {
            children: [
              (0, c.jsxs)("div", {
                className: a().row2222,
                children: [
                  (0, c.jsx)("div", {
                    className: a().bottom,
                    children: (0, c.jsx)(z, {
                      url: "/careers/developer",
                      title: "Web d3veloper / 4rchitect",
                      icon: (0, c.jsx)(r.default, {}),
                      index: 0,
                    }),
                  }),
                  (0, c.jsx)("div", {}),
                  (0, c.jsx)("div", {
                    children: (0, c.jsx)(z, {
                      url: "/careers/creative-developer",
                      title: "Creat1ve developer / animator",
                      icon: (0, c.jsx)(n.default, {}),
                      index: 1,
                    }),
                  }),
                  (0, c.jsx)(z, {
                    url: "/careers/internships",
                    title: "Developers + Designers",
                    type: "3-6 months",
                    headline: "Internships",
                    icon: (0, c.jsx)(t.default, {}),
                    index: 2,
                  }),
                ],
              }),
              (0, c.jsxs)("div", {
                className: a().row2222,
                children: [
                  (0, c.jsx)("div", {}),
                  (0, c.jsx)(z, {
                    url: "/careers/ux",
                    title: "UX-designer",
                    place: "Remote",
                    type: "Freelance",
                    icon: (0, c.jsx)(t.default, {}),
                    index: 3,
                  }),
                ],
              }),
            ],
          });
      var m = w;
    },
    5434: function (e, A, s) {
      "use strict";
      s.r(A);
      var c = s(5893);
      let t = () =>
        (0, c.jsxs)("svg", {
          version: "1.1",
          xmlns: "http://www.w3.org/2000/svg",
          x: "0px",
          y: "0px",
          viewBox: "0 0 240 320",
          children: [
            (0, c.jsx)("path", {
              d: "M230,320c-73.33,0-146.67,0-220,0c0.02-13.36,0.05-26.71,0.07-40.07c0,0-0.14,0.14-0.14,0.14c73.38,0,146.76,0,220.14,0 l-0.14-0.14C229.95,293.29,229.98,306.64,230,320z M219.78,290.33c-66.76,0-133.13,0-199.4,0c0,6.74,0,13.13,0,19.44 c66.65,0,132.91,0,199.4,0C219.78,303.24,219.78,296.97,219.78,290.33z",
            }),
            (0, c.jsx)("path", {
              d: "M0,280c0-86.67,0-173.33,0-260c3.36-0.02,6.71-0.05,10.07-0.07c-0.03,2.16-0.08,4.33-0.08,6.49 c-0.02,84.55-0.04,169.1-0.06,253.66c0,0,0.14-0.14,0.14-0.14C6.71,279.95,3.36,279.98,0,280z",
            }),
            (0, c.jsx)("path", {
              d: "M240,20c0,86.67,0,173.33,0,260c-3.36-0.02-6.71-0.05-10.07-0.07l0.14,0.14c-0.02-29.13-0.04-58.25-0.05-87.38 c-0.03-57.59-0.06-115.18-0.08-172.76C233.29,19.95,236.64,19.98,240,20z",
            }),
            (0, c.jsx)("path", {
              d: "M20,0c66.67,0,133.33,0,200,0c0.02,3.36,0.05,6.71,0.07,10.07c-66.71,0-133.43,0-200.14,0C19.95,6.71,19.98,3.36,20,0z",
            }),
            (0, c.jsx)("path", {
              d: "M230.07,20.07c-3.13,0-6.27,0-10.14,0c0-3.62,0-6.88,0-10.14c3.13,0,6.27,0,10.14,0 C230.07,13.55,230.07,16.81,230.07,20.07z",
            }),
            (0, c.jsx)("path", {
              d: "M20.07,9.93c0,3.13,0,6.27,0,10.14c-3.62,0-6.88,0-10.14,0c0-3.13,0-6.27,0-10.14C13.55,9.93,16.81,9.93,20.07,9.93z",
            }),
            (0, c.jsx)("path", {
              d: "M40.09,40.07c0-3.14,0-6.28,0-9.73c53.23,0,106.22,0,159.83,0c0,3.22,0,6.47,0,9.73l0.16-0.14c-53.38,0-106.76,0-160.14,0 L40.09,40.07z",
            }),
            (0, c.jsx)("path", {
              d: "M199.91,179.93c0,3.14,0,6.28,0,9.73c-53.23,0-106.22,0-159.83,0c0-3.22,0-6.47,0-9.73c0,0-0.16,0.14-0.16,0.14 c53.38,0,106.76,0,160.14,0L199.91,179.93z",
            }),
            (0, c.jsx)("path", {
              d: "M40.09,179.93c-3.14,0-6.28,0-9.74,0c0-46.58,0-92.91,0-139.86c3.22,0,6.48,0,9.74,0c0,0-0.16-0.14-0.16-0.14 c0,46.71,0,93.43,0,140.14L40.09,179.93z",
            }),
            (0, c.jsx)("path", {
              d: "M199.91,40.07c3.14,0,6.28,0,9.74,0c0,46.57,0,92.91,0,139.86c-3.22,0-6.48,0-9.74,0c0,0,0.16,0.14,0.16,0.14 c0-46.71,0-93.43,0-140.14L199.91,40.07z",
            }),
            (0, c.jsx)("path", {
              d: "M199.74,230.35c0,3.3,0,6.23,0,9.39c-19.8,0-39.36,0-59.32,0c0-2.97,0-6.01,0-9.39 C159.99,230.35,179.68,230.35,199.74,230.35z",
            }),
            (0, c.jsx)("path", {
              d: "M30.24,249.63c0-3.25,0-6.17,0-9.35c6.58,0,12.93,0,19.52,0c0,3.16,0,6.08,0,9.35C43.38,249.63,37.02,249.63,30.24,249.63z ",
            }),
            (0, c.jsx)("path", {
              d: "M140.05,149.91c-16.7,0-33.41-0.01-50.11-0.01l0.15,0.15c0-3.13,0-6.26,0-9.71c16.56,0,32.89,0,49.81,0 c0,3.22,0,6.47,0,9.72L140.05,149.91z",
            }),
            (0, c.jsx)("path", {
              d: "M139.9,130.06c3.15,0,6.3,0,9.75,0c0,3.49,0,6.74,0,10l0.07-0.15c-3.15,0-6.3,0-9.75,0c0-3.48,0-6.74,0-10 C139.97,129.91,139.9,130.06,139.9,130.06z",
            }),
            (0, c.jsx)("path", {
              d: "M89.94,129.9c0,3.12,0,6.24,0,9.72c-3.2,0-6.23,0-9.6,0c0-2.95,0-5.98,0-9.57c3.26,0,6.5,0,9.75,0 C90.09,130.05,89.94,129.9,89.94,129.9z",
            }),
            (0, c.jsx)("path", {
              d: "M159.91,70.29c-0.04,6.66-0.08,13.32-0.13,19.98c0,0.01,0.14-0.32,0.14-0.31c-3.4-0.21-6.79-0.43-10.19-0.66 c-0.01-0.01,0.16,0.28,0.16,0.27c0.07-6.44,0.14-12.87,0.22-19.3l-0.15,0.29c3.37,0.01,6.74,0.01,10.11,0.02 C160.06,70.58,159.91,70.29,159.91,70.29z",
            }),
            (0, c.jsx)("path", {
              d: "M110.42,110.64c3.12,0,6.24,0,9.72,0c0,3.2,0,6.23,0,9.59c-2.95,0-5.98,0-9.57,0c0-3.26,0-6.5,0-9.74 C110.57,110.49,110.42,110.64,110.42,110.64z",
            }),
            (0, c.jsx)("path", {
              d: "M80.1,89.8c-3.39-0.03-6.77-0.05-10.16-0.08l0.15,0.29c0-6.54,0.01-13.09,0.01-19.63l-0.15,0.29 c3.37,0.01,6.74,0.01,10.11,0.02l-0.15-0.29c0.01,6.56,0.03,13.13,0.04,19.69C79.95,90.09,80.1,89.8,80.1,89.8z",
            }),
            (0, c.jsx)("path", {
              d: "M129.71,70.28c0,16.7-0.01,33.41-0.01,50.11l0.15-0.15c-3.13,0-6.26,0-9.71,0c0-16.56,0-32.89,0-49.81 c3.22,0,6.47,0,9.72,0L129.71,70.28z",
            }),
          ],
        });
      A.default = t;
    },
    3067: function (e, A, s) {
      "use strict";
      s.r(A);
      var c = s(5893);
      let t = () =>
        (0, c.jsxs)("svg", {
          version: "1.1",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 240 320",
          children: [
            (0, c.jsx)("path", {
              d: "M230,320c-73.33,0-146.67,0-220,0c0.02-13.36,0.05-26.71,0.07-40.07c0,0-0.14,0.14-0.14,0.14c73.38,0,146.76,0,220.14,0 l-0.14-0.14C229.95,293.29,229.98,306.64,230,320z M219.78,290.33c-66.76,0-133.13,0-199.4,0c0,6.74,0,13.13,0,19.44 c66.65,0,132.91,0,199.4,0C219.78,303.24,219.78,296.97,219.78,290.33z",
            }),
            (0, c.jsx)("path", {
              d: "M0,280c0-86.67,0-173.33,0-260c3.36-0.02,6.71-0.05,10.07-0.07c-0.03,2.16-0.08,4.33-0.08,6.49 c-0.02,84.55-0.04,169.1-0.06,253.66c0,0,0.14-0.14,0.14-0.14C6.71,279.95,3.36,279.98,0,280z",
            }),
            (0, c.jsx)("path", {
              d: "M240,20c0,86.67,0,173.33,0,260c-3.36-0.02-6.71-0.05-10.07-0.07l0.14,0.14c-0.02-29.13-0.04-58.25-0.05-87.38 c-0.03-57.59-0.06-115.18-0.08-172.76C233.29,19.95,236.64,19.98,240,20z",
            }),
            (0, c.jsx)("path", {
              d: "M20,0c66.67,0,133.33,0,200,0c0.02,3.36,0.05,6.71,0.07,10.07c-66.71,0-133.43,0-200.14,0C19.95,6.71,19.98,3.36,20,0z",
            }),
            (0, c.jsx)("path", {
              d: "M230.07,20.07c-3.13,0-6.27,0-10.14,0c0-3.62,0-6.88,0-10.14c3.13,0,6.27,0,10.14,0C230.07,13.55,230.07,16.81,230.07,20.07 z",
            }),
            (0, c.jsx)("path", {
              d: "M20.07,9.93c0,3.13,0,6.27,0,10.14c-3.62,0-6.88,0-10.14,0c0-3.13,0-6.27,0-10.14C13.55,9.93,16.81,9.93,20.07,9.93z",
            }),
            (0, c.jsx)("path", {
              d: "M40.09,40.07c0-3.14,0-6.28,0-9.73c53.23,0,106.22,0,159.83,0c0,3.22,0,6.47,0,9.73l0.16-0.14c-53.38,0-106.76,0-160.14,0 L40.09,40.07z",
            }),
            (0, c.jsx)("path", {
              d: "M199.91,179.93c0,3.14,0,6.28,0,9.73c-53.23,0-106.22,0-159.83,0c0-3.22,0-6.47,0-9.73c0,0-0.16,0.14-0.16,0.14 c53.38,0,106.76,0,160.14,0L199.91,179.93z",
            }),
            (0, c.jsx)("path", {
              d: "M40.09,179.93c-3.14,0-6.28,0-9.74,0c0-46.58,0-92.91,0-139.86c3.22,0,6.48,0,9.74,0c0,0-0.16-0.14-0.16-0.14 c0,46.71,0,93.43,0,140.14L40.09,179.93z",
            }),
            (0, c.jsx)("path", {
              d: "M199.91,40.07c3.14,0,6.28,0,9.74,0c0,46.57,0,92.91,0,139.86c-3.22,0-6.48,0-9.74,0c0,0,0.16,0.14,0.16,0.14 c0-46.71,0-93.43,0-140.14L199.91,40.07z",
            }),
            (0, c.jsx)("path", {
              d: "M199.74,230.35c0,3.3,0,6.23,0,9.39c-19.8,0-39.36,0-59.32,0c0-2.97,0-6.01,0-9.39 C159.99,230.35,179.68,230.35,199.74,230.35z",
            }),
            (0, c.jsx)("path", {
              d: "M30.24,249.63c0-3.25,0-6.17,0-9.35c6.58,0,12.93,0,19.52,0c0,3.16,0,6.08,0,9.35C43.38,249.63,37.02,249.63,30.24,249.63z",
            }),
            (0, c.jsx)("path", {
              d: "M140.05,149.91c-16.7,0-33.41-0.01-50.11-0.01l0.15,0.15c0-3.13,0-6.26,0-9.71c16.56,0,32.89,0,49.81,0 c0,3.22,0,6.47,0,9.72L140.05,149.91z",
            }),
            (0, c.jsx)("path", {
              d: "M139.9,150.06c6.47,0,12.93,0,20,0c0,3.49,0,6.74,0,10l0.15-0.15c-6.46,0-12.92,0-20,0c0-3.48,0-6.74,0-10 C140.05,149.91,139.9,150.06,139.9,150.06z",
            }),
            (0, c.jsx)("path", {
              d: "M119.91,119.95c0,3.12,0,6.25,0,9.7c-6.54,0-12.9,0-19.81,0c0-3.23,0-6.47,0-9.71l-0.15,0.15c6.7,0,13.41,0.01,20.11,0.01 L119.91,119.95z",
            }),
            (0, c.jsx)("path", {
              d: "M159.77,90.28c3.24,0,6.48,0,9.96,0c0,3.1,0,6,0,9.31c-2.94,0-5.96,0-9.82,0c0-3.04,0-6.25,0.01-9.47 C159.92,90.11,159.77,90.28,159.77,90.28z",
            }),
            (0, c.jsx)("path", {
              d: "M100.1,119.94c-3.12,0-6.24,0-9.72,0c0-3.2,0-6.23,0-9.59c2.95,0,5.98,0,9.57,0c0,3.26,0,6.5,0,9.74 C99.95,120.09,100.1,119.94,100.1,119.94z",
            }),
            (0, c.jsx)("path", {
              d: "M120.06,120.1c0-3.12,0-6.24,0-9.72c3.2,0,6.23,0,9.59,0c0,2.95,0,5.98,0,9.57c-3.26,0-6.5,0-9.74,0 C119.91,119.95,120.06,120.1,120.06,120.1z",
            }),
            (0, c.jsx)("path", {
              d: "M149.72,89.77c0,3.24,0,6.48,0,9.96c-3.1,0-6,0-9.31,0c0-2.93,0-5.96,0-9.82c3.03,0,6.25,0,9.47,0.01 C149.89,89.92,149.72,89.77,149.72,89.77z",
            }),
            (0, c.jsx)("path", {
              d: "M79.95,90.09c3.14,0,6.28,0,9.72,0c0,3.31,0,6.36,0,9.65c-3.1,0-6.03,0-9.57,0c0-3.28,0-6.54,0-9.8L79.95,90.09z",
            }),
            (0, c.jsx)("path", {
              d: "M89.94,149.9c0,3.12,0,6.24,0,9.72c-3.2,0-6.23,0-9.6,0c0-2.95,0-5.98,0-9.57c3.26,0,6.5,0,9.75,0 C90.09,150.05,89.94,149.9,89.94,149.9z",
            }),
            (0, c.jsx)("path", {
              d: "M159.91,79.95c-0.04,3.44-0.08,6.88-0.13,10.33c0,0.01,0.14-0.16,0.14-0.16c-3.4-0.11-6.79-0.22-10.19-0.34 c-0.01,0,0.16,0.14,0.16,0.14c0.07-3.33,0.14-6.65,0.22-9.97l-0.15,0.15c3.37,0,6.74,0.01,10.11,0.01 C160.06,80.1,159.91,79.95,159.91,79.95z",
            }),
            (0, c.jsx)("path", {
              d: "M159.9,160.06c3.12,0,6.24,0,9.72,0c0,3.2,0,6.23,0,9.59c-2.95,0-5.98,0-9.57,0c0-3.26,0-6.5,0-9.74 C160.05,159.91,159.9,160.06,159.9,160.06z",
            }),
            (0, c.jsx)("path", {
              d: "M80.1,89.94c-3.39-0.01-6.77-0.03-10.16-0.04l0.15,0.15c0-3.37,0.01-6.74,0.01-10.11l-0.15,0.15 c3.37,0,6.74,0.01,10.11,0.01l-0.15-0.15c0.01,3.38,0.03,6.76,0.04,10.14C79.95,90.09,80.1,89.94,80.1,89.94z",
            }),
            (0, c.jsx)("path", {
              d: "M160.06,80.1c0-3.12,0-6.24,0-9.72c3.2,0,6.23,0,9.59,0c0,2.95,0,5.98,0,9.57c-3.26,0-6.5,0-9.74,0 C159.91,79.95,160.06,80.1,160.06,80.1z",
            }),
            (0, c.jsx)("path", {
              d: "M150.1,79.94c-3.12,0-6.24,0-9.72,0c0-3.2,0-6.23,0-9.59c2.95,0,5.98,0,9.57,0c0,3.26,0,6.5,0,9.74 C149.95,80.09,150.1,79.94,150.1,79.94z",
            }),
            (0, c.jsx)("path", {
              d: "M80.06,80.1c0-3.12,0-6.24,0-9.72c3.2,0,6.23,0,9.59,0c0,2.95,0,5.98,0,9.57c-3.26,0-6.5,0-9.74,0 C79.91,79.95,80.06,80.1,80.06,80.1z",
            }),
            (0, c.jsx)("path", {
              d: "M70.1,79.94c-3.12,0-6.24,0-9.72,0c0-3.2,0-6.23,0-9.59c2.95,0,5.98,0,9.57,0c0,3.26,0,6.5,0,9.74 C69.95,80.09,70.1,79.94,70.1,79.94z",
            }),
            (0, c.jsx)("path", {
              d: "M69.94,89.9c0,3.12,0,6.24,0,9.72c-3.2,0-6.23,0-9.59,0c0-2.95,0-5.98,0-9.57c3.26,0,6.5,0,9.74,0 C70.09,90.05,69.94,89.9,69.94,89.9z",
            }),
          ],
        });
      A.default = t;
    },
    2475: function (e) {
      e.exports = { benefits: "CareersFooter_benefits__hC_Y_" };
    },
    274: function (e) {
      e.exports = {
        wrapper: "Image_wrapper__CEf6Z",
        loaded: "Image_loaded__4V492",
        loader: "Image_loader__d_Pxc",
        letters: "Image_letters__VlOak",
        textMode: "Image_textMode__sZj32",
      };
    },
    2936: function (e) {
      e.exports = {
        job: "Job_job__GiXP2",
        ssr: "Job_ssr__Ynvv0",
        innerlink: "Job_innerlink__VJ8Qb",
        apply: "Job_apply__fWwXf",
        icon: "Job_icon__1wIi_",
        text: "Job_text__n2e6a",
      };
    },
    4808: function (e) {
      e.exports = {
        container: "careers_container__HOK11",
        reasons: "careers_reasons__jTxz1",
        caption: "careers_caption__0Aff5",
      };
    },
  },
]);
